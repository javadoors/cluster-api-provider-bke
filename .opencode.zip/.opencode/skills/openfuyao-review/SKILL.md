---
name: openfuyao-review
description: Use when the user wants to analyze a developer's contributions to the openFuyao community on GitCode, including code statistics, review issues, issue tracking, and code quality assessment. Triggers on keywords like "openfuyao", "openFuyao", "社区贡献", "社区贡献分析", "community contribution", "openfuyao code review", or when asking about a developer's openFuyao contributions, commit statistics, lines of code, PR reviews, or issue tracking.
---

# openFuyao 社区开发者贡献分析 Skill

分析开发者在 openFuyao 社区各仓库中的贡献情况，生成包含代码统计、检视问题、Issue 跟踪和代码质量评估的综合报告。报告内容全部使用中文输出。

## 输入格式

从 `$ARGUMENTS` 解析以下参数：

```
<gitcode_id> [access_token] <start_date>~<end_date> [org]
```

- `access_token` 可选。未提供时从 `$env:GITCODE_TOKEN` 读取。
- `org` 可选，默认为 `openFuyao`。可指定其他组织名以分析不同社区。

示例：
```
zhangsan ghp_xxxxxxxxxxxx 2025-01-01~2025-06-01
zhangsan 2025-01-01~2025-06-01
zhangsan 2025-01-01~2025-06-01 openFuyao
```

如缺少必需参数，请向用户询问。

## Token 解析

按以下优先级解析访问令牌：

1. 从参数中识别日期范围参数（匹配 `YYYY-MM-DD~YYYY-MM-DD`）。第一个参数为 `USERNAME`。剩余参数中，不匹配日期范围模式且不是有效组织名的参数：若看起来像 token（长字母数字串，通常 20+ 字符），视为 `ACCESS_TOKEN`。
2. 否则读取 `$env:GITCODE_TOKEN`。
3. 若两者均不可用，停止执行并提示用户：

```powershell
$env:GITCODE_TOKEN = "your-token-here"
```

Token 获取地址：https://gitcode.com/setting/token-classic

## 执行流程

### 步骤 1：解析输入

从 `$ARGUMENTS` 提取：
- `USERNAME`：GitCode 用户 ID（必需）
- `ACCESS_TOKEN`：API 令牌（可选，回退到 `$env:GITCODE_TOKEN`）
- `START_DATE`：时间段开始（ISO 格式：YYYY-MM-DD）
- `END_DATE`：时间段结束（ISO 格式：YYYY-MM-DD）
- `ORG`：组织名（可选，默认 `openFuyao`）

### 步骤 2：发现组织下的仓库

通过分页 API 列出目标组织下的所有仓库。

```powershell
$headers = @{ "Authorization" = "Bearer $TOKEN" }
$baseUrl = "https://api.gitcode.com/api/v5"

# 封装带重试的 API 调用函数
function Invoke-GitCodeApi {
    param([string]$Uri, [hashtable]$Headers, [int]$MaxRetries = 3)
    for ($i = 0; $i -lt $MaxRetries; $i++) {
        try {
            return Invoke-RestMethod -Uri $Uri -Headers $Headers -Method Get -TimeoutSec 30
        } catch {
            $statusCode = $_.Exception.Response.StatusCode.value__
            if ($statusCode -eq 401) { throw "认证失败 (401)。Token 无效或已过期，请前往 https://gitcode.com/setting/token-classic 重新生成" }
            if ($statusCode -eq 404) { throw "资源未找到 (404)。请检查组织名和用户名是否正确。" }
            if ($statusCode -eq 429 -and $i -lt $MaxRetries - 1) {
                $wait = [Math]::Pow(2, $i + 1)
                Start-Sleep -Seconds $wait
                continue
            }
            if ($i -eq $MaxRetries - 1) { throw "API 调用失败（重试 $MaxRetries 次后）: $($_.Exception.Message)" }
        }
    }
}

$repos = @()
$page = 1
do {
    $url = "$baseUrl/orgs/$ORG/repos?per_page=100&page=$page"
    $response = Invoke-GitCodeApi -Uri $url -Headers $headers
    if ($null -eq $response -or $response.Count -eq 0) { break }
    $repos += $response | ForEach-Object { $_.full_name }
    $page++
} while ($response.Count -eq 100)

if ($repos.Count -eq 0) {
    Write-Host "未在组织 '$ORG' 下发现任何仓库。请检查组织名（默认：openFuyao）。"
    return
}
Write-Host "发现 $($repos.Count) 个仓库属于 '$ORG'。"
```

### 步骤 3：通过 GitCode API 采集数据

对每个发现的仓库执行以下 API 调用。

#### 3.1 获取用户提交记录

采集时将每个 commit 与其所属仓库关联存储，避免后续步骤中 repo 信息丢失。

```powershell
$allCommits = @()
$contributedRepos = @{}

foreach ($repo in $repos) {
    $parts = $repo -split "/", 2
    $owner = $parts[0]
    $repoName = $parts[1]

    $page = 1
    $repoCommitCount = 0
    do {
        $url = "$baseUrl/repos/$owner/$repoName/commits?author=$USERNAME&since=${START_DATE}T00:00:00Z&until=${END_DATE}T23:59:59Z&per_page=100&page=$page"
        $response = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -eq $response -or $response.Count -eq 0) { break }
        foreach ($commit in $response) {
            # 关联仓库信息到每个 commit
            $commit | Add-Member -NotePropertyName repo_full_name -NotePropertyValue $repo
            $commit | Add-Member -NotePropertyName repo_owner -NotePropertyValue $owner
            $commit | Add-Member -NotePropertyName repo_name -NotePropertyValue $repoName
            $allCommits += $commit
        }
        $repoCommitCount += $response.Count
        $page++
    } while ($response.Count -eq 100)

    if ($repoCommitCount -gt 0) {
        $contributedRepos[$repo] = $repoCommitCount
    }
}

if ($allCommits.Count -eq 0) {
    Write-Host "未找到用户 '$USERNAME' 在组织 '$ORG' 中 $START_DATE ~ $END_DATE 期间的提交记录。"
    Write-Host "请检查：(1) 用户名是否正确 (2) 时间段是否覆盖活跃期 (3) 组织名是否正确"
}
```

#### 3.2 获取代码行数统计

通过 commit detail API 获取每个 commit 的 additions/deletions 统计。注意：必须使用每个 commit 自身关联的 owner/repo，而非循环外的变量。

```powershell
$totalAdded = 0
$totalDeleted = 0
$totalFiles = 0

foreach ($commit in $allCommits) {
    # 使用 commit 自身关联的仓库信息
    $owner = $commit.repo_owner
    $repoName = $commit.repo_name
    $url = "$baseUrl/repos/$owner/$repoName/commits/$($commit.sha)"
    $detail = Invoke-GitCodeApi -Uri $url -Headers $headers
    if ($detail.stats) {
        $totalAdded += $detail.stats.additions
        $totalDeleted += $detail.stats.deletions
        $totalFiles += $detail.stats.total
    }
}
```

#### 3.3 获取 Pull Request 列表（用于检视问题分析）

```powershell
$allPRs = @()
foreach ($repo in $repos) {
    $parts = $repo -split "/", 2
    $owner = $parts[0]
    $repoName = $parts[1]

    $page = 1
    do {
        $url = "$baseUrl/repos/$owner/$repoName/pulls?state=all&per_page=100&page=$page"
        $response = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -eq $response -or $response.Count -eq 0) { break }
        $userPRs = $response | Where-Object {
            $_.user.login -eq $USERNAME -and
            $_.created_at -ge $START_DATE -and
            $_.created_at -le $END_DATE
        }
        foreach ($pr in $userPRs) {
            $pr | Add-Member -NotePropertyName repo_full_name -NotePropertyValue $repo
            $pr | Add-Member -NotePropertyName repo_owner -NotePropertyValue $owner
            $pr | Add-Member -NotePropertyName repo_name -NotePropertyValue $repoName
            $allPRs += $pr
        }
        $page++
    } while ($response.Count -eq 100)
}
```

#### 3.4 获取 PR 检视评论（检视问题数）

过滤机器人账号（如 `openFuyao-bot`），只统计人工检视意见。同时利用 PR 自身的 `notes` 字段作为检视活动参考指标。

```powershell
$reviewIssueCount = 0        # 人工检视意见数
$botCommentCount = 0         # 机器人评论数
$totalNotes = 0              # PR notes 字段总计

# 已知的机器人账号列表
$botAccounts = @("openFuyao-bot", "openfuyao-bot", "gitcode-bot")

foreach ($pr in $allPRs) {
    $owner = $pr.repo_owner
    $repoName = $pr.repo_name
    $totalNotes += $pr.notes

    $url = "$baseUrl/repos/$owner/$repoName/pulls/$($pr.number)/comments"
    $comments = Invoke-GitCodeApi -Uri $url -Headers $headers
    if ($null -ne $comments) {
        foreach ($comment in $comments) {
            if ($comment.user.login -in $botAccounts) {
                $botCommentCount++
            } else {
                $reviewIssueCount++
            }
        }
    }
}
```

#### 3.5 获取用户创建的 Issue

```powershell
$allIssues = @()
foreach ($repo in $repos) {
    $parts = $repo -split "/", 2
    $owner = $parts[0]
    $repoName = $parts[1]

    $page = 1
    do {
        $url = "$baseUrl/repos/$owner/$repoName/issues?creator=$USERNAME&since=${START_DATE}T00:00:00Z&per_page=100&page=$page"
        $response = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -eq $response -or $response.Count -eq 0) { break }
        foreach ($issue in $response) {
            $issue | Add-Member -NotePropertyName repo_full_name -NotePropertyValue $repo
            $allIssues += $issue
        }
        $page++
    } while ($response.Count -eq 100)
}
```

#### 3.6 获取代码变更详情（用于质量分析）

优先通过 PR files API 获取文件变更（commit diff API 可能返回 404）。若用户有 PR，从 PR files 获取；若无 PR，从 commit detail 获取变更文件列表。最多采样 10 个代表性变更用于 AI 分析。

```powershell
$allDiffs = @()

# 方式一：通过 PR files API 获取（推荐，数据更完整）
foreach ($pr in $allPRs) {
    $owner = $pr.repo_owner
    $repoName = $pr.repo_name
    $url = "$baseUrl/repos/$owner/$repoName/pulls/$($pr.number)/files"
    $files = Invoke-GitCodeApi -Uri $url -Headers $headers
    if ($null -ne $files) {
        foreach ($file in $files) {
            $file | Add-Member -NotePropertyName repo_full_name -NotePropertyValue $pr.repo_full_name
            $file | Add-Member -NotePropertyName pr_number -NotePropertyValue $pr.number
            $allDiffs += $file
        }
    }
}

# 方式二：若无 PR，通过 commit 采样获取变更文件
if ($allDiffs.Count -eq 0 -and $allCommits.Count -gt 0) {
    $sampleSize = [Math]::Min(10, $allCommits.Count)
    $sampleCommits = $allCommits | Sort-Object { Get-Random } | Select-Object -First $sampleSize

    foreach ($commit in $sampleCommits) {
        $owner = $commit.repo_owner
        $repoName = $commit.repo_name
        # 通过 commit detail API 获取变更统计
        $url = "$baseUrl/repos/$owner/$repoName/commits/$($commit.sha)"
        $detail = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -ne $detail) {
            $detail | Add-Member -NotePropertyName repo_full_name -NotePropertyValue $commit.repo_full_name
            $allDiffs += $detail
        }
    }
}
```

### 步骤 4：汇总统计数据

跨所有仓库计算并汇总：

| 指标 | 数据来源 |
|------|----------|
| 提交总数 | Commits API 计数 |
| 新增代码行数 | Commit detail API stats.additions |
| 删除代码行数 | Commit detail API stats.deletions |
| 净代码行数 | 新增 - 删除 |
| PR 数量 | PRs API 计数 |
| 人工检视意见数 | PR comments API（过滤机器人后） |
| 创建 Issue 数 | Issues API 计数 |
| 变更文件数 | Commit detail / PR files 分析 |
| 贡献仓库数 | 提交采集时追踪 |

若某指标为 0 或不可用，显示为 `0` 并附说明（如"未发现 PR — 检视评分仅基于提交质量"）。

### 步骤 5：AI 代码质量评估

分析采集到的代码变更和元数据，对每个维度按 1-5 分制评分。

#### 5.1 需求设计

评估要点：
- PR 关联 Issue 的比例（反映需求可追溯性）
- Issue 描述质量（清晰度、验收标准）
- 提交信息质量（是否引用需求/工单号）

评分标准：
- 5分：>90% PR 关联了描述充分的 Issue，提交信息清晰
- 4分：70-90% PR 关联 Issue，Issue 描述较好
- 3分：50-70% PR 关联 Issue，Issue 描述最少
- 2分：<50% PR 关联 Issue，可追溯性差
- 1分：无 Issue 跟踪，无需求引用

#### 5.2 代码开发

评估要点：
- 代码 diff 质量（可读性、命名规范、结构）
- 提交粒度（逻辑原子提交 vs 大批量提交）
- diff 中可见的编码规范遵循情况
- 所写代码的复杂度和可维护性

评分标准：
- 5分：代码整洁、结构良好、原子提交、遵循规范
- 4分：代码质量好、多数为原子提交
- 3分：质量可接受、存在部分大提交
- 2分：质量不稳定、频繁大提交
- 1分：代码质量差、无提交纪律

#### 5.3 代码重构

评估要点：
- diff 中是否存在重构模式（提取方法、重命名、简化）
- 是否减少了代码重复
- 是否在不改变行为的前提下改进了现有代码结构
- 是否清理了死代码或技术债务

评分标准：
- 5分：积极重构，有明确的改进模式
- 4分：可见规律性的重构 effort
- 3分：偶有重构
- 2分：很少重构，技术债务累积
- 1分：无重构，存在复制粘贴模式

#### 5.4 开发者测试

评估要点：
- 测试文件变更占总变更的比例
- 功能代码旁是否伴有新测试用例
- 测试质量（有意义的断言、边界用例）
- diff 中可见的测试覆盖模式

评分标准：
- 5分：>30% 测试文件，测试用例全面
- 4分：20-30% 测试文件，测试覆盖良好
- 3分：10-20% 测试文件，基础测试
- 2分：<10% 测试文件，测试极少
- 1分：无测试文件变更

#### 5.5 代码检视

评估要点：
- PR 检视参与度（收到和回复的评论）
- 检视回复质量（ thoughtful 修复 vs 敷衍了事）
- PR 描述质量（上下文、测试说明）
- 检视周转时间指标

评分标准：
- 5分：积极检视参与，回复有深度，PR 描述详尽
- 4分：检视参与良好，PR 描述充分
- 3分：检视参与度一般
- 2分：检视参与度低
- 1分：无检视参与

### 步骤 6：生成报告

输出以下中文 Markdown 报告：

```markdown
# openFuyao 社区开发者质量评估报告

## 基本信息
- **开发者**：{username}
- **社区/组织**：{org}（默认：openFuyao）
- **时间段**：{start_date} ~ {end_date}
- **扫描仓库数**：{扫描发现的仓库总数}
- **贡献仓库数**：{实际有贡献的仓库数}

## 核心指标

| 指标 | 数值 |
|------|------|
| 新增代码行数 | +{count} |
| 删除代码行数 | -{count} |
| 净代码行数 | {count} |
| 检视问题数（人工检视意见） | {count} |
| 提交 Issue 数 | {count} |

## 完整统计

| 指标 | 数值 |
|------|------|
| 提交总数 | {count} |
| Pull Request 数 | {count} |
| 变更文件数 | {count} |
| PR 总评论数（含机器人） | {count} |
| 机器人评论数 | {count} |

## 贡献仓库明细

| 仓库 | 提交数 |
|------|--------|
| {owner/repo} | {count} |
| ... | ... |

## PR 明细

| PR 号 | 仓库 | 标题 | 状态 | 新增行 | 删除行 | 评论数 |
|-------|------|------|------|--------|--------|--------|
| #{number} | {repo} | {title} | {state} | +{added} | -{removed} | {notes} |
| ... | ... | ... | ... | ... | ... | ... |

## 质量评估

| 维度 | 评分 (1-5) | 评语 |
|------|-----------|------|
| 需求设计 | {score} | {简要评语} |
| 代码开发 | {score} | {简要评语} |
| 代码重构 | {score} | {简要评语} |
| 开发者测试 | {score} | {简要评语} |
| 代码检视 | {score} | {简要评语} |
| **综合** | **{avg}** | **{总体评语}** |

### 评分等级说明
- 4.5-5.0：优秀
- 3.5-4.4：良好
- 2.5-3.4：合格
- 1.0-2.4：需改进

## 详细分析

### 需求设计
{基于采集数据的详细分析，包含具体示例}

### 代码开发
{基于代码 diff 示例的详细分析}

### 代码重构
{基于发现的重构示例的详细分析}

### 开发者测试
{基于测试覆盖观察的详细分析}

### 代码检视
{基于检视参与数据的详细分析}

## 改进建议

1. {建议 1}
2. {建议 2}
3. {建议 3}

## 亮点

- {正面观察 1}
- {正面观察 2}
```

## 错误处理

- API 返回 401：Token 无效或已过期。提示用户前往 https://gitcode.com/setting/token-classic 重新生成。
- API 返回 404：组织、仓库或用户未找到。请检查组织名（默认：openFuyao）、仓库路径和用户名。
- API 返回 429：触发速率限制。使用指数退避重试（2秒、4秒、8秒），最多重试 3 次。
- 未发现仓库：请检查组织名是否正确，以及 token 是否有访问权限。
- 未发现提交：显示清晰的提示信息，包含排查步骤（检查用户名、时间段、组织名）。
- Token 缺失（参数和环境变量均无）：立即停止并显示两种获取方式的说明。

## 注意事项

- GitCode API 速率限制：400 次/分钟，4000 次/小时
- openFuyao 组织约有 110 个仓库；遍历所有仓库使用 author 过滤在速率限制内，但可能耗时较长
- 大仓库需对所有 API 调用进行分页（per_page=100）
- 无用户提交的仓库会快速跳过（空响应中断分页）
- 最多采样 10 个 commit/PR 的 diff 用于 AI 分析，以控制在合理时间内
- 所有日期使用 ISO 8601 格式
- Commits API 的 `author` 参数接受用户名或邮箱
- 参数传入的 token 优先级高于 `$env:GITCODE_TOKEN`
- 组织名默认为 `openFuyao`；指定其他组织名可分析不同社区
- PR 评论中需过滤机器人账号（如 `openFuyao-bot`），只统计人工检视意见
- PR 列表 API 已返回 `added_lines`/`removed_lines`/`notes` 字段，可直接利用以减少 API 调用次数
- commit diff API (`/commits/{sha}/diff`) 可能返回 404，建议优先使用 PR files API (`/pulls/{number}/files`) 获取文件变更
