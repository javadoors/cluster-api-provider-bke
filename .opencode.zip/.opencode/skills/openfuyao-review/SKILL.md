---
name: openfuyao-review
description: Use when the user wants to analyze a developer's contributions to the openFuyao community on GitCode, including code statistics, review issues, issue tracking, and code quality assessment. Triggers on keywords like "openfuyao", "openFuyao", "社区贡献", "社区贡献分析", "community contribution", "openfuyao code review", or when asking about a developer's openFuyao contributions, commit statistics, lines of code, PR reviews, or issue tracking.
---

# openFuyao 社区开发者贡献分析 Skill

分析开发者在 openFuyao 社区各仓库中的贡献情况，生成包含代码统计、检视问题、Issue 跟踪和代码质量评估的综合报告。报告内容全部使用中文输出。

## 输入格式

从 `$ARGUMENTS` 解析以下参数：

```
<gitcode_id> [access_token] <start_date>~<end_date> [org]
```

- `access_token` 可选。未提供时从 `$env:GITCODE_TOKEN` 读取。
- `org` 可选，默认为 `openFuyao`。可指定其他组织名以分析不同社区。

示例：
```
zhangsan ghp_xxxxxxxxxxxx 2025-01-01~2025-06-01
zhangsan 2025-01-01~2025-06-01
zhangsan 2025-01-01~2025-06-01 openFuyao
```

如缺少必需参数，请向用户询问。

## Token 解析

按以下优先级解析访问令牌：

1. 从参数中识别日期范围参数（匹配 `YYYY-MM-DD~YYYY-MM-DD`）。第一个参数为 `USERNAME`。剩余参数中，不匹配日期范围模式且不是有效组织名的参数：若看起来像 token（长字母数字串，通常 20+ 字符），视为 `ACCESS_TOKEN`。
2. 否则读取 `$env:GITCODE_TOKEN`。
3. 若两者均不可用，停止执行并提示用户：

```powershell
$env:GITCODE_TOKEN = "your-token-here"
```

Token 获取地址：https://gitcode.com/setting/token-classic

## 执行流程

### 步骤 1：解析输入

从 `$ARGUMENTS` 提取：
- `USERNAME`：GitCode 用户 ID（必需）
- `ACCESS_TOKEN`：API 令牌（可选，回退到 `$env:GITCODE_TOKEN`）
- `START_DATE`：时间段开始（ISO 格式：YYYY-MM-DD）
- `END_DATE`：时间段结束（ISO 格式：YYYY-MM-DD）
- `ORG`：组织名（可选，默认 `openFuyao`）

### 步骤 2：发现组织下的仓库

通过分页 API 列出目标组织下的所有仓库。

```powershell
$headers = @{ "Authorization" = "Bearer $TOKEN" }
$baseUrl = "https://api.gitcode.com/api/v5"

# 封装带重试的 API 调用函数
function Invoke-GitCodeApi {
    param([string]$Uri, [hashtable]$Headers, [int]$MaxRetries = 3)
    for ($i = 0; $i -lt $MaxRetries; $i++) {
        try {
            return Invoke-RestMethod -Uri $Uri -Headers $Headers -Method Get -TimeoutSec 30
        } catch {
            $statusCode = $_.Exception.Response.StatusCode.value__
            if ($statusCode -eq 401) { throw "认证失败 (401)。Token 无效或已过期，请前往 https://gitcode.com/setting/token-classic 重新生成" }
            if ($statusCode -eq 404) { throw "资源未找到 (404)。请检查组织名和用户名是否正确。" }
            if ($statusCode -eq 429 -and $i -lt $MaxRetries - 1) {
                $wait = [Math]::Pow(2, $i + 1)
                Start-Sleep -Seconds $wait
                continue
            }
            if ($i -eq $MaxRetries - 1) { throw "API 调用失败（重试 $MaxRetries 次后）: $($_.Exception.Message)" }
        }
    }
}

$repos = @()
$page = 1
do {
    $url = "$baseUrl/orgs/$ORG/repos?per_page=100&page=$page"
    $response = Invoke-GitCodeApi -Uri $url -Headers $headers
    if ($null -eq $response -or $response.Count -eq 0) { break }
    $repos += $response | ForEach-Object { $_.full_name }
    $page++
} while ($response.Count -eq 100)

if ($repos.Count -eq 0) {
    Write-Host "未在组织 '$ORG' 下发现任何仓库。请检查组织名（默认：openFuyao）。"
    return
}
Write-Host "发现 $($repos.Count) 个仓库属于 '$ORG'。"
```

### 步骤 3：通过 GitCode API 采集数据

对每个发现的仓库执行以下 API 调用。

#### 3.1 获取用户提交记录

采集时将每个 commit 与其所属仓库关联存储，避免后续步骤中 repo 信息丢失。

```powershell
$allCommits = @()
$contributedRepos = @{}

foreach ($repo in $repos) {
    $parts = $repo -split "/", 2
    $owner = $parts[0]
    $repoName = $parts[1]

    $page = 1
    $repoCommitCount = 0
    do {
        $url = "$baseUrl/repos/$owner/$repoName/commits?author=$USERNAME&since=${START_DATE}T00:00:00Z&until=${END_DATE}T23:59:59Z&per_page=100&page=$page"
        $response = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -eq $response -or $response.Count -eq 0) { break }
        foreach ($commit in $response) {
            # 关联仓库信息到每个 commit
            $commit | Add-Member -NotePropertyName repo_full_name -NotePropertyValue $repo
            $commit | Add-Member -NotePropertyName repo_owner -NotePropertyValue $owner
            $commit | Add-Member -NotePropertyName repo_name -NotePropertyValue $repoName
            $allCommits += $commit
        }
        $repoCommitCount += $response.Count
        $page++
    } while ($response.Count -eq 100)

    if ($repoCommitCount -gt 0) {
        $contributedRepos[$repo] = $repoCommitCount
    }
}

if ($allCommits.Count -eq 0) {
    Write-Host "未找到用户 '$USERNAME' 在组织 '$ORG' 中 $START_DATE ~ $END_DATE 期间的提交记录。"
    Write-Host "请检查：(1) 用户名是否正确 (2) 时间段是否覆盖活跃期 (3) 组织名是否正确"
}
```

#### 3.2 获取代码行数统计

通过 commit detail API 获取每个 commit 的 additions/deletions 统计。注意：必须使用每个 commit 自身关联的 owner/repo，而非循环外的变量。

```powershell
$totalAdded = 0
$totalDeleted = 0
$totalFiles = 0

foreach ($commit in $allCommits) {
    # 使用 commit 自身关联的仓库信息
    $owner = $commit.repo_owner
    $repoName = $commit.repo_name
    $url = "$baseUrl/repos/$owner/$repoName/commits/$($commit.sha)"
    $detail = Invoke-GitCodeApi -Uri $url -Headers $headers
    if ($detail.stats) {
        $totalAdded += $detail.stats.additions
        $totalDeleted += $detail.stats.deletions
        $totalFiles += $detail.stats.total
    }
}
```

#### 3.3 获取 Pull Request 列表（用于检视问题分析）

```powershell
$allPRs = @()
foreach ($repo in $repos) {
    $parts = $repo -split "/", 2
    $owner = $parts[0]
    $repoName = $parts[1]

    $page = 1
    do {
        $url = "$baseUrl/repos/$owner/$repoName/pulls?state=all&per_page=100&page=$page"
        $response = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -eq $response -or $response.Count -eq 0) { break }
        $userPRs = $response | Where-Object {
            $_.user.login -eq $USERNAME -and
            $_.created_at -ge $START_DATE -and
            $_.created_at -le $END_DATE
        }
        foreach ($pr in $userPRs) {
            $pr | Add-Member -NotePropertyName repo_full_name -NotePropertyValue $repo
            $pr | Add-Member -NotePropertyName repo_owner -NotePropertyValue $owner
            $pr | Add-Member -NotePropertyName repo_name -NotePropertyValue $repoName
            $allPRs += $pr
        }
        $page++
    } while ($response.Count -eq 100)
}
```

#### 3.4 获取 PR 检视评论（检视问题数）

过滤机器人账号（如 `openFuyao-bot`），只统计人工检视意见。同时利用 PR 自身的 `notes` 字段作为检视活动参考指标。

```powershell
$reviewIssueCount = 0        # 人工检视意见数
$botCommentCount = 0         # 机器人评论数
$totalNotes = 0              # PR notes 字段总计

# 已知的机器人账号列表
$botAccounts = @("openFuyao-bot", "openfuyao-bot", "gitcode-bot")

foreach ($pr in $allPRs) {
    $owner = $pr.repo_owner
    $repoName = $pr.repo_name
    $totalNotes += $pr.notes

    $url = "$baseUrl/repos/$owner/$repoName/pulls/$($pr.number)/comments"
    $comments = Invoke-GitCodeApi -Uri $url -Headers $headers
    if ($null -ne $comments) {
        foreach ($comment in $comments) {
            if ($comment.user.login -in $botAccounts) {
                $botCommentCount++
            } else {
                $reviewIssueCount++
            }
        }
    }
}
```

#### 3.5 获取用户创建的 Issue

```powershell
$allIssues = @()
foreach ($repo in $repos) {
    $parts = $repo -split "/", 2
    $owner = $parts[0]
    $repoName = $parts[1]

    $page = 1
    do {
        $url = "$baseUrl/repos/$owner/$repoName/issues?creator=$USERNAME&since=${START_DATE}T00:00:00Z&per_page=100&page=$page"
        $response = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -eq $response -or $response.Count -eq 0) { break }
        foreach ($issue in $response) {
            $issue | Add-Member -NotePropertyName repo_full_name -NotePropertyValue $repo
            $allIssues += $issue
        }
        $page++
    } while ($response.Count -eq 100)
}
```

#### 3.6 获取代码变更详情（用于质量分析）

优先通过 PR files API 获取文件变更（commit diff API 可能返回 404）。若用户有 PR，从 PR files 获取；若无 PR，从 commit detail 获取变更文件列表。最多采样 10 个代表性变更用于 AI 分析。

```powershell
$allDiffs = @()

# 方式一：通过 PR files API 获取（推荐，数据更完整）
foreach ($pr in $allPRs) {
    $owner = $pr.repo_owner
    $repoName = $pr.repo_name
    $url = "$baseUrl/repos/$owner/$repoName/pulls/$($pr.number)/files"
    $files = Invoke-GitCodeApi -Uri $url -Headers $headers
    if ($null -ne $files) {
        foreach ($file in $files) {
            $file | Add-Member -NotePropertyName repo_full_name -NotePropertyValue $pr.repo_full_name
            $file | Add-Member -NotePropertyName pr_number -NotePropertyValue $pr.number
            $allDiffs += $file
        }
    }
}

# 方式二：若无 PR，通过 commit 采样获取变更文件
if ($allDiffs.Count -eq 0 -and $allCommits.Count -gt 0) {
    $sampleSize = [Math]::Min(10, $allCommits.Count)
    $sampleCommits = $allCommits | Sort-Object { Get-Random } | Select-Object -First $sampleSize

    foreach ($commit in $sampleCommits) {
        $owner = $commit.repo_owner
        $repoName = $commit.repo_name
        # 通过 commit detail API 获取变更统计
        $url = "$baseUrl/repos/$owner/$repoName/commits/$($commit.sha)"
        $detail = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -ne $detail) {
            $detail | Add-Member -NotePropertyName repo_full_name -NotePropertyValue $commit.repo_full_name
            $allDiffs += $detail
        }
    }
}
```

### 步骤 4：汇总统计数据

跨所有仓库计算并汇总：

| 指标 | 数据来源 |
|------|----------|
| 提交总数 | Commits API 计数 |
| 新增代码行数 | Commit detail API stats.additions |
| 删除代码行数 | Commit detail API stats.deletions |
| 净代码行数 | 新增 - 删除 |
| PR 数量 | PRs API 计数 |
| 人工检视意见数 | PR comments API（过滤机器人后） |
| 创建 Issue 数 | Issues API 计数 |
| 变更文件数 | Commit detail / PR files 分析 |
| 贡献仓库数 | 提交采集时追踪 |

若某指标为 0 或不可用，显示为 `0` 并附说明（如"未发现 PR — 检视评分仅基于提交质量"）。

### 步骤 5：AI 代码质量评估

#### 评估前覆盖性检查

在开始评分前，先列举所有采集到的 PR 和设计文档清单，确保：
1. 每个重要 PR（尤其是设计文档、OFEP、大变更）在相关子维度中被分析
2. 交叉检查：是否有重要 PR 在任何子维度中被遗漏
3. 特别关注非代码类 PR（文档、设计、流程规范）在"需求设计"和"软件设计"维度中的覆盖

分析采集到的代码变更和元数据，对每个维度按 1-5 分制评分。

#### 5.1 需求设计

从以下 6 个子维度评估，每个子维度按 1-5 分评分，最终取加权平均。

**5.1.1 需求分析方法**

评估开发者是否采用系统化的需求分析方法：
- 是否使用用户故事、用例分析、场景驱动等方法梳理需求
- Issue/PR 描述中是否体现需求背景和业务价值
- 是否有需求优先级判断和范围界定

评分标准：
- 5分：系统化运用多种需求分析方法，需求背景清晰、业务价值明确
- 4分：采用规范的需求分析方法，需求描述较清晰
- 3分：有基本的需求描述，但方法不够系统化
- 2分：需求描述零散，缺乏分析方法
- 1分：无需求分析，直接编码

**5.1.2 需求建模**

评估需求建模能力：
- 是否使用 UML（用例图、时序图、状态图等）进行需求建模
- 是否有领域模型设计（实体、值对象、聚合根等）
- 是否有状态机模型描述业务流程
- 设计文档中是否有模型图或结构化描述

评分标准：
- 5分：完整的 UML 建模 + 领域模型 + 状态机，模型与代码一致
- 4分：有较完整的需求建模，模型清晰
- 3分：有基本的模型描述，但不够完整
- 2分：建模零散，缺乏系统性
- 1分：无需求建模

**5.1.3 功能需求**

评估功能需求识别的完整性：
- 功能需求是否被完整识别和拆分
- 是否有明确的验收标准
- PR 关联 Issue 的比例（反映需求可追溯性）
- 提交信息是否引用需求/工单号

评分标准：
- 5分：>90% PR 关联 Issue，功能需求完整拆分，验收标准明确
- 4分：70-90% PR 关联 Issue，功能需求较完整
- 3分：50-70% PR 关联 Issue，功能需求基本覆盖
- 2分：<50% PR 关联 Issue，功能需求零散
- 1分：无 Issue 跟踪，无需求引用

**5.1.4 非功能需求**

评估非功能需求的识别和处理（逐项检查以下维度）：
- **性能**：是否考虑吞吐量、延迟、资源占用等指标
- **Security（安全）**：是否考虑认证、授权、加密、输入校验等
- **Safety（功能安全）**：是否考虑故障安全状态、危险识别
- **可靠性**：是否考虑容错、重试、幂等、数据一致性
- **可用性**：是否考虑降级、熔断、限流、健康检查
- **兼容性**：是否考虑版本兼容、向后兼容、平台兼容
- **可测试性**：是否考虑可观测性、可 Mock 性、测试钩子

评分标准：
- 5分：覆盖 6+ 项非功能需求，每项均有设计措施
- 4分：覆盖 4-5 项，措施较完善
- 3分：覆盖 2-3 项，措施基本到位
- 2分：覆盖 1 项或措施不足
- 1分：未考虑非功能需求

**5.1.5 技术洞察**

评估技术选型和风险识别能力：
- 技术选型是否有对比分析和决策依据
- 是否识别技术风险并提出缓解措施
- 是否关注行业趋势和最佳实践
- 是否有技术创新或改进提案

评分标准：
- 5分：有详细的技术选型对比 + 风险识别 + 创新提案
- 4分：有技术选型依据和风险识别
- 3分：有基本的技术选型说明
- 2分：技术选型缺乏依据
- 1分：无技术洞察

**5.1.6 关键技术分析报告**

评估是否输出关键技术分析文档：
- 是否产出技术分析报告/设计文档
- 报告是否涵盖背景、方案对比、选型理由、风险分析
- 报告质量（结构化程度、深度、可读性）
- 设计文档行数和完整度（如 design.md、detailed-design.md 等）

评分标准：
- 5分：输出完整的技术分析报告，涵盖背景/对比/选型/风险，结构化程度高
- 4分：有较完整的技术分析文档
- 3分：有基本的设计文档
- 2分：文档零散或过于简略
- 1分：无技术分析文档

**需求设计综合评分** = (5.1.1 + 5.1.2 + 5.1.3 + 5.1.4 + 5.1.5 + 5.1.6) / 6，四舍五入

#### 5.2 软件设计

从以下 9 个子维度评估，每个按 1-5 分评分，最终取加权平均。

**5.2.1 设计文档输出**

- 是否产出软件设计文档（如 detailed-design.md、developer_guide.md 等）
- 设计文档的完整度和深度
- 文档是否与代码实现保持一致
- 是否包含接口定义、数据模型、交互流程

评分标准：
- 5分：完整的设计文档，含接口/数据模型/交互流程，与代码一致
- 4分：有较完整的设计文档
- 3分：有基本的设计文档
- 2分：文档零散
- 1分：无设计文档

**5.2.2 4+1 视图**

评估是否从多视图进行架构设计：
- **逻辑视图**：类图、包结构、模块划分
- **开发视图**：代码组织、分层结构、模块依赖
- **进程视图**：并发模型、进程/线程结构、通信机制
- **物理视图**：部署拓扑、节点分布、网络拓扑
- **场景视图**：关键用例的端到端流程

评分标准：
- 5分：完整覆盖 5 个视图，每个视图描述清晰
- 4分：覆盖 4 个视图
- 3分：覆盖 2-3 个视图
- 2分：覆盖 1 个视图
- 1分：无视图设计

**5.2.3 安全威胁分析**

评估安全威胁建模能力：
- 是否使用 STRIDE（伪装/篡改/抵赖/信息泄露/拒绝服务/提权）等方法进行威胁分析
- 是否识别攻击面和信任边界
- 是否有安全加固措施（RBAC、网络策略、密钥管理等）
- 代码中是否有输入校验、权限检查等安全编码实践

评分标准：
- 5分：完整的 STRIDE 威胁分析 + 安全加固措施 + 安全编码实践
- 4分：有威胁识别和安全措施
- 3分：有基本的安全编码实践
- 2分：安全考虑不足
- 1分：无安全设计

**5.2.4 可靠与可用性设计**

评估可靠性和可用性设计：
- **容错**：错误处理、异常恢复、优雅降级
- **重试与幂等**：失败重试机制、幂等性保证
- **熔断与限流**：过载保护机制
- **冗余与高可用**：多副本、故障转移
- **健康检查**：就绪/存活探针设计

评分标准：
- 5分：完整覆盖容错/重试/熔断/冗余/健康检查
- 4分：覆盖 3-4 项
- 3分：覆盖 2 项
- 2分：覆盖 1 项
- 1分：无可靠性与可用性设计

**5.2.5 可测试性设计**

评估代码的可测试性：
- **依赖注入**：是否使用 DI 便于 Mock
- **接口隔离**：是否定义清晰接口便于替换
- **测试钩子**：是否有测试专用入口或配置
- **可观测性**：是否有日志、指标、追踪支持
- **测试分层**：是否有单元/集成/E2E 测试分层设计

评分标准：
- 5分：完整覆盖 DI/接口隔离/测试钩子/可观测性/分层测试
- 4分：覆盖 3-4 项
- 3分：覆盖 2 项
- 2分：覆盖 1 项
- 1分：无可测试性设计

**5.2.6 功能安全设计**

评估功能安全设计（适用于安全关键系统）：
- 是否识别危险和风险
- 是否定义安全状态和故障响应
- 是否有诊断覆盖率设计
- 是否有故障检测和隔离机制
- 代码中是否有防御性编程（边界检查、空值处理等）

评分标准：
- 5分：完整的安全状态/故障响应/诊断/检测/防御性编程
- 4分：覆盖 3-4 项
- 3分：覆盖 2 项
- 2分：覆盖 1 项
- 1分：无功能安全设计

**5.2.7 体验设计**

评估开发者/用户体验设计：
- **API 易用性**：接口设计是否直觉、一致
- **错误提示**：错误信息是否清晰、可操作
- **文档配套**：是否有快速入门、示例、FAQ
- **配置体验**：配置项是否合理、有默认值和说明
- **部署体验**：是否提供 Helm Chart/部署脚本/一键部署

评分标准：
- 5分：完整覆盖 API 易用性/错误提示/文档/配置/部署体验
- 4分：覆盖 3-4 项
- 3分：覆盖 2 项
- 2分：覆盖 1 项
- 1分：无体验设计

**5.2.8 设计原则与模式**

评估设计原则和模式的应用：
- **SOLID 原则**：单一职责、开闭原则、里氏替换、接口隔离、依赖倒置
- **DRY/KISS/YAGNI 原则**：是否避免重复、保持简洁、不过度设计
- **设计模式**：工厂/策略/观察者/适配器/装饰器等模式的合理使用
- **反模式识别**：是否避免上帝类、循环依赖、硬编码等

评分标准：
- 5分：系统化运用 SOLID + DRY/KISS + 多种设计模式，无反模式
- 4分：运用主要设计原则和部分模式
- 3分：有基本的设计原则应用
- 2分：设计原则应用不足
- 1分：无设计原则意识，存在大量反模式

**5.2.9 架构腐化点识别与改进**

评估是否主动识别并组织架构改进：
- 是否识别架构腐化点（循环依赖、上帝类、紧耦合、重复代码等）
- 是否有重构计划和技术债务清理
- 是否有架构守护机制（依赖检查、代码规范检查等）
- 重构 PR 是否在不改变行为的前提下改进结构

评分标准：
- 5分：主动识别腐化点 + 有重构计划 + 架构守护机制 + 持续改进
- 4分：识别腐化点并有重构行动
- 3分：偶有重构改进
- 2分：很少重构，技术债务累积
- 1分：无架构改进意识

**软件设计综合评分** = (5.2.1 + 5.2.2 + 5.2.3 + 5.2.4 + 5.2.5 + 5.2.6 + 5.2.7 + 5.2.8 + 5.2.9) / 9，四舍五入

#### 5.3 代码开发

评估要点：
- 代码 diff 质量（可读性、命名规范、结构）
- 提交粒度（逻辑原子提交 vs 大批量提交）
- diff 中可见的编码规范遵循情况
- 所写代码的复杂度和可维护性

评分标准：
- 5分：代码整洁、结构良好、原子提交、遵循规范
- 4分：代码质量好、多数为原子提交
- 3分：质量可接受、存在部分大提交
- 2分：质量不稳定、频繁大提交
- 1分：代码质量差、无提交纪律

#### 5.4 代码重构

评估要点：
- diff 中是否存在重构模式（提取方法、重命名、简化）
- 是否减少了代码重复
- 是否在不改变行为的前提下改进了现有代码结构
- 是否清理了死代码或技术债务

评分标准：
- 5分：积极重构，有明确的改进模式
- 4分：可见规律性的重构 effort
- 3分：偶有重构
- 2分：很少重构，技术债务累积
- 1分：无重构，存在复制粘贴模式

#### 5.5 开发者测试

评估要点：
- 测试文件变更占总变更的比例
- 功能代码旁是否伴有新测试用例
- 测试质量（有意义的断言、边界用例）
- diff 中可见的测试覆盖模式

评分标准：
- 5分：>30% 测试文件，测试用例全面
- 4分：20-30% 测试文件，测试覆盖良好
- 3分：10-20% 测试文件，基础测试
- 2分：<10% 测试文件，测试极少
- 1分：无测试文件变更

#### 5.6 代码检视

评估要点：
- PR 检视参与度（收到和回复的评论）
- 检视回复质量（ thoughtful 修复 vs 敷衍了事）
- PR 描述质量（上下文、测试说明）
- 检视周转时间指标

评分标准：
- 5分：积极检视参与，回复有深度，PR 描述详尽
- 4分：检视参与良好，PR 描述充分
- 3分：检视参与度一般
- 2分：检视参与度低
- 1分：无检视参与

### 步骤 6：生成报告

输出以下中文 Markdown 报告：

```markdown
# openFuyao 社区开发者质量评估报告

## 基本信息
- **开发者**：{username}
- **社区/组织**：{org}（默认：openFuyao）
- **时间段**：{start_date} ~ {end_date}
- **扫描仓库数**：{扫描发现的仓库总数}
- **贡献仓库数**：{实际有贡献的仓库数}

## 核心指标

| 指标 | 数值 |
|------|------|
| 新增代码行数 | +{count} |
| 删除代码行数 | -{count} |
| 净代码行数 | {count} |
| 检视问题数（人工检视意见） | {count} |
| 提交 Issue 数 | {count} |

## 完整统计

| 指标 | 数值 |
|------|------|
| 提交总数 | {count} |
| Pull Request 数 | {count} |
| 变更文件数 | {count} |
| PR 总评论数（含机器人） | {count} |
| 机器人评论数 | {count} |

## 贡献仓库明细

| 仓库 | 提交数 |
|------|--------|
| {owner/repo} | {count} |
| ... | ... |

## PR 明细

| PR 号 | 仓库 | 标题 | 状态 | 新增行 | 删除行 | 评论数 |
|-------|------|------|------|--------|--------|--------|
| #{number} | {repo} | {title} | {state} | +{added} | -{removed} | {notes} |
| ... | ... | ... | ... | ... | ... | ... |

## 质量评估

| 维度 | 评分 (1-5) | 评语 |
|------|-----------|------|
| 需求设计 | {score} | {简要评语，涵盖需求分析方法/建模/功能非功能/技术洞察} |
| 软件设计 | {score} | {简要评语，涵盖4+1视图/安全威胁/可靠性/可测试性/设计模式} |
| 代码开发 | {score} | {简要评语} |
| 代码重构 | {score} | {简要评语} |
| 开发者测试 | {score} | {简要评语} |
| 代码检视 | {score} | {简要评语} |
| **综合** | **{avg}** | **{总体评语}** |

### 评分等级说明
- 4.0-5.0：优秀
- 3.0-3.9：良好
- 2.0-2.9：合格
- 1.0-1.9：需改进

## 详细分析

### 需求设计

#### 需求分析方法
{分析开发者是否采用系统化的需求分析方法，如用户故事、用例分析、场景驱动等}

#### 需求建模
{分析是否使用 UML、领域模型、状态机等进行需求建模}

#### 功能需求
{分析功能需求识别的完整性、PR-Issue 关联比例、验收标准}

#### 非功能需求
{逐项分析以下维度的覆盖情况：性能/Security/Safety/可靠性/可用性/兼容性/可测试性}

#### 技术洞察
{分析技术选型依据、风险识别、行业趋势关注}

#### 关键技术分析报告
{分析是否输出关键技术分析文档，报告质量和深度}

### 软件设计

#### 设计文档输出
{分析设计文档的完整度、深度、与代码一致性}

#### 4+1 视图
{分析逻辑视图/开发视图/进程视图/物理视图/场景视图的覆盖情况}

#### 安全威胁分析
{分析是否使用 STRIDE 等方法进行威胁建模，安全加固措施}

#### 可靠与可用性设计
{分析容错/重试/熔断/冗余/健康检查等设计}

#### 可测试性设计
{分析依赖注入/接口隔离/测试钩子/可观测性/测试分层}

#### 功能安全设计
{分析安全状态/故障响应/诊断/防御性编程}

#### 体验设计
{分析 API 易用性/错误提示/文档配套/配置体验/部署体验}

#### 设计原则与模式
{分析 SOLID/DRY/KISS 原则应用和设计模式使用}

#### 架构腐化点识别与改进
{分析是否识别循环依赖/上帝类/紧耦合等腐化点并组织改进}

### 代码开发
{基于代码 diff 示例的详细分析}

### 代码重构
{基于发现的重构示例的详细分析}

### 开发者测试
{基于测试覆盖观察的详细分析}

### 代码检视
{基于检视参与数据的详细分析}

## 改进建议

1. {建议 1}
2. {建议 2}
3. {建议 3}

## 最终评价意见

具体意见（覆盖全部6个维度，每条融入2个维度，有建设性，让考核人有切实感受）：
1. {需求设计 + 软件设计维度的评价}
2. {代码开发 + 代码重构维度的评价}
3. {开发者测试 + 代码检视维度的评价}

待改进点（覆盖全部6个维度，每条融入2个维度）：
1. {需求设计/软件设计方面的待改进点}
2. {代码开发/代码重构方面的待改进点}
3. {开发者测试/代码检视方面的待改进点}

典型代码链接（不超过3条）：
1. {PR 或代码文件链接1，附简要说明}
2. {PR 或代码文件链接2，附简要说明}
3. {PR 或代码文件链接3，附简要说明}

## 亮点

- {正面观察 1}
- {正面观察 2}

## 评价等级

**{良好/优秀}**

等级判定标准：
- **优秀**：综合评分 ≥ 4.0，且无任何维度低于 3 分
- **良好**：其他情况
```

## 错误处理

- API 返回 401：Token 无效或已过期。提示用户前往 https://gitcode.com/setting/token-classic 重新生成。
- API 返回 404：组织、仓库或用户未找到。请检查组织名（默认：openFuyao）、仓库路径和用户名。
- API 返回 429：触发速率限制。使用指数退避重试（2秒、4秒、8秒），最多重试 3 次。
- 未发现仓库：请检查组织名是否正确，以及 token 是否有访问权限。
- 未发现提交：显示清晰的提示信息，包含排查步骤（检查用户名、时间段、组织名）。
- Token 缺失（参数和环境变量均无）：立即停止并显示两种获取方式的说明。

## 注意事项

- GitCode API 速率限制：400 次/分钟，4000 次/小时
- openFuyao 组织约有 110 个仓库；遍历所有仓库使用 author 过滤在速率限制内，但可能耗时较长
- 大仓库需对所有 API 调用进行分页（per_page=100）
- 无用户提交的仓库会快速跳过（空响应中断分页）
- 最多采样 10 个 commit/PR 的 diff 用于 AI 分析，以控制在合理时间内
- 所有日期使用 ISO 8601 格式
- Commits API 的 `author` 参数接受用户名或邮箱
- 参数传入的 token 优先级高于 `$env:GITCODE_TOKEN`
- 组织名默认为 `openFuyao`；指定其他组织名可分析不同社区
- PR 评论中需过滤机器人账号（如 `openFuyao-bot`），只统计人工检视意见
- PR 列表 API 已返回 `added_lines`/`removed_lines`/`notes` 字段，可直接利用以减少 API 调用次数
- commit diff API (`/commits/{sha}/diff`) 可能返回 404，建议优先使用 PR files API (`/pulls/{number}/files`) 获取文件变更
