---
name: gitcode-review
description: Use when the user wants to analyze a developer's GitCode contributions, code statistics, review issues, or perform code quality assessment. Triggers on keywords like "gitcode", "code review report", "developer assessment", "code quality", "white box analysis", or when asking about commit statistics, lines of code, PR reviews, or issue tracking on gitcode.com.
---

# GitCode Developer Review Skill

Analyze a developer's contributions on GitCode and generate a comprehensive quality assessment report.

## Input Format

Parse `$ARGUMENTS` for the following parameters:

```
<gitcode_username> [access_token] <start_date>~<end_date> <owner/repo1,owner/repo2,...>
```

The `access_token` is optional. If omitted, the skill reads from `$env:GITCODE_TOKEN`.

Examples:
```
zhangsan ghp_xxxxxxxxxxxx 2025-01-01~2025-06-01 myorg/project-a,myorg/project-b
zhangsan 2025-01-01~2025-06-01 myorg/project-a,myorg/project-b
```

If any required parameter is missing, ask the user to provide it.

## Token Resolution

Resolve the access token in this order:

1. If the second argument matches a token pattern (non-empty string that is NOT a date range `YYYY-MM-DD~YYYY-MM-DD`), treat it as `ACCESS_TOKEN`.
2. Otherwise, read `$env:GITCODE_TOKEN`.
3. If neither is available, stop and instruct the user:

```powershell
$env:GITCODE_TOKEN = "your-token-here"
```

Token can be obtained from: https://gitcode.com/setting/token-classic

## Execution Workflow

### Step 1: Parse Input

Extract from `$ARGUMENTS`:
- `USERNAME`: GitCode user ID (required)
- `ACCESS_TOKEN`: API token (optional, falls back to `$env:GITCODE_TOKEN`)
- `START_DATE`: Period start (ISO format: YYYY-MM-DD)
- `END_DATE`: Period end (ISO format: YYYY-MM-DD)
- `REPOS`: Array of `owner/repo` strings

### Step 2: Collect Data via GitCode API

For each repository in `REPOS`, execute the following API calls using `Invoke-RestMethod`.

Wrap every API call in a retry helper:

```powershell
function Invoke-GitCodeApi {
    param([string]$Uri, [hashtable]$Headers, [int]$MaxRetries = 3)
    for ($i = 0; $i -lt $MaxRetries; $i++) {
        try {
            return Invoke-RestMethod -Uri $Uri -Headers $Headers -Method Get -TimeoutSec 30
        } catch {
            $statusCode = $_.Exception.Response.StatusCode.value__
            if ($statusCode -eq 401) { throw "Authentication failed (401). Token is invalid or expired. Please regenerate at https://gitcode.com/setting/token-classic" }
            if ($statusCode -eq 404) { throw "Resource not found (404). Verify repository path and username." }
            if ($statusCode -eq 429 -and $i -lt $MaxRetries - 1) {
                $wait = [Math]::Pow(2, $i + 1)
                Write-Host "Rate limited. Retrying in ${wait}s..."
                Start-Sleep -Seconds $wait
                continue
            }
            if ($i -eq $MaxRetries - 1) { throw "API call failed after $MaxRetries retries: $($_.Exception.Message)" }
        }
    }
}
```

#### 2.1 Get Commits by User

```powershell
$headers = @{ "Authorization" = "Bearer $TOKEN" }
$baseUrl = "https://api.gitcode.com/api/v5"

$allCommits = @()
foreach ($repo in $repos) {
    $parts = $repo -split "/", 2
    $owner = $parts[0]
    $repoName = $parts[1]

    $page = 1
    do {
        $url = "$baseUrl/repos/$owner/$repoName/commits?author=$USERNAME&since=${START_DATE}T00:00:00Z&until=${END_DATE}T23:59:59Z&per_page=100&page=$page"
        $response = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -eq $response -or $response.Count -eq 0) { break }
        $allCommits += $response
        $page++
    } while ($response.Count -eq 100)
}

if ($allCommits.Count -eq 0) {
    Write-Host "No commits found for user '$USERNAME' in the specified period and repositories."
    Write-Host "Please verify: (1) username is correct, (2) date range covers active periods, (3) repos are correct."
}
```

#### 2.2 Get Code Contribution Statistics

```powershell
$totalAdded = 0
$totalDeleted = 0
$totalFiles = 0

foreach ($commit in $allCommits) {
    $url = "$baseUrl/repos/$owner/$repoName/commits/$($commit.sha)"
    $detail = Invoke-GitCodeApi -Uri $url -Headers $headers
    if ($detail.stats) {
        $totalAdded += $detail.stats.additions
        $totalDeleted += $detail.stats.deletions
        $totalFiles += $detail.stats.total
    }
}
```

#### 2.3 Get Pull Requests (for Review Issues)

```powershell
$allPRs = @()
foreach ($repo in $repos) {
    $parts = $repo -split "/", 2
    $owner = $parts[0]
    $repoName = $parts[1]

    $page = 1
    do {
        $url = "$baseUrl/repos/$owner/$repoName/pulls?state=all&per_page=100&page=$page"
        $response = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -eq $response -or $response.Count -eq 0) { break }
        $userPRs = $response | Where-Object {
            $_.user.login -eq $USERNAME -and
            $_.created_at -ge $START_DATE -and
            $_.created_at -le $END_DATE
        }
        $allPRs += $userPRs
        $page++
    } while ($response.Count -eq 100)
}
```

#### 2.4 Get PR Review Comments (Review Issues Count)

```powershell
$reviewIssueCount = 0
foreach ($pr in $allPRs) {
    $url = "$baseUrl/repos/$owner/$repoName/pulls/$($pr.number)/comments"
    $comments = Invoke-GitCodeApi -Uri $url -Headers $headers
    if ($null -ne $comments) {
        $reviewIssueCount += $comments.Count
    }
}
```

#### 2.5 Get Issues Created by User

```powershell
$allIssues = @()
foreach ($repo in $repos) {
    $parts = $repo -split "/", 2
    $owner = $parts[0]
    $repoName = $parts[1]

    $page = 1
    do {
        $url = "$baseUrl/repos/$owner/$repoName/issues?creator=$USERNAME&since=${START_DATE}T00:00:00Z&per_page=100&page=$page"
        $response = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -eq $response -or $response.Count -eq 0) { break }
        $allIssues += $response
        $page++
    } while ($response.Count -eq 100)
}
```

#### 2.6 Get Commit Diffs (for Quality Analysis)

Select up to 10 representative commits spread across the time period for AI analysis:

```powershell
$sampleSize = [Math]::Min(10, $allCommits.Count)
if ($sampleSize -gt 0) {
    $sampleCommits = $allCommits | Sort-Object { Get-Random } | Select-Object -First $sampleSize

    $allDiffs = @()
    foreach ($commit in $sampleCommits) {
        $url = "$baseUrl/repos/$owner/$repoName/commits/$($commit.sha)/diff"
        $diff = Invoke-GitCodeApi -Uri $url -Headers $headers
        if ($null -ne $diff) {
            $allDiffs += $diff
        }
    }
}
```

### Step 3: Aggregate Statistics

Compute and summarize across all repositories:

| Metric | Source |
|--------|--------|
| Total commits | Commits API count |
| Lines added | Commit statistics / diff analysis |
| Lines deleted | Commit statistics / diff analysis |
| Net lines of code | Added - Deleted |
| PR count | PRs API count |
| PR review comments received | PR comments API count |
| Issues created | Issues API count |
| Files changed | Commit diff analysis |

If any metric is 0 or unavailable, display it as `0` with a note (e.g., "No PRs found — review score based on commit quality only").

### Step 4: AI Quality Assessment

Analyze the collected commit diffs and metadata to score each dimension on a 1-5 scale.

#### 4.1 Requirements Design

Evaluate:
- Ratio of PRs linked to Issues (indicates requirement traceability)
- Quality of Issue descriptions (clarity, acceptance criteria)
- Commit message quality (references to requirements/tickets)

Scoring:
- 5: >90% PRs linked to well-described Issues, clear commit messages
- 4: 70-90% PRs linked, decent Issue descriptions
- 3: 50-70% PRs linked, minimal Issue descriptions
- 2: <50% PRs linked, poor traceability
- 1: No Issue tracking, no requirement references

#### 4.2 Code Development

Evaluate:
- Code diff quality (readability, naming conventions, structure)
- Commit granularity (logical, atomic commits vs. large dumps)
- Adherence to coding standards visible in diffs
- Complexity and maintainability of written code

Scoring:
- 5: Clean, well-structured code, atomic commits, follows conventions
- 4: Good code quality, mostly atomic commits
- 3: Acceptable quality, some large commits
- 2: Inconsistent quality, frequent large commits
- 1: Poor code quality, no commit discipline

#### 4.3 Code Refactoring

Evaluate:
- Presence of refactoring patterns in diffs (extract method, rename, simplify)
- Reduction of code duplication
- Improvement of existing code structure without changing behavior
- Removal of dead code or technical debt

Scoring:
- 5: Active refactoring, clear improvement patterns
- 4: Regular refactoring efforts visible
- 3: Occasional refactoring
- 2: Rare refactoring, accumulating tech debt
- 1: No refactoring, copy-paste patterns

#### 4.4 Developer Testing

Evaluate:
- Ratio of test file changes to total changes
- Presence of new test cases alongside feature code
- Test quality (meaningful assertions, edge cases)
- Test coverage patterns visible in diffs

Scoring:
- 5: >30% test files, comprehensive test cases
- 4: 20-30% test files, good test coverage
- 3: 10-20% test files, basic tests
- 2: <10% test files, minimal testing
- 1: No test files changed

#### 4.5 Code Review

Evaluate:
- PR review participation (comments received and responded to)
- Quality of review responses (thoughtful fixes vs. dismissals)
- PR description quality (context, testing notes)
- Review turnaround time indicators

Scoring:
- 5: Active review engagement, thoughtful responses, detailed PR descriptions
- 4: Good review participation, adequate PR descriptions
- 3: Moderate review engagement
- 2: Minimal review participation
- 1: No review engagement

### Step 5: Generate Report

Output the following Markdown report:

```markdown
# GitCode Developer Quality Report

## Basic Information
- **Developer**: {username}
- **Period**: {start_date} ~ {end_date}
- **Repositories**: {repo list}

## Core Metrics

| Metric | Value |
|--------|-------|
| Lines of Code (Added) | +{count} |
| Lines of Code (Deleted) | -{count} |
| Net Lines of Code | {count} |
| Review Issues (PR Comments) | {count} |
| Issues Created | {count} |

## Full Statistics

| Metric | Value |
|--------|-------|
| Total Commits | {count} |
| Pull Requests | {count} |
| Files Changed | {count} |

## Quality Assessment

| Dimension | Score (1-5) | Assessment |
|-----------|-------------|------------|
| Requirements Design | {score} | {brief assessment} |
| Code Development | {score} | {brief assessment} |
| Code Refactoring | {score} | {brief assessment} |
| Developer Testing | {score} | {brief assessment} |
| Code Review | {score} | {brief assessment} |
| **Overall** | **{avg}** | **{overall assessment}** |

## Detailed Analysis

### Requirements Design
{detailed analysis with examples from collected data}

### Code Development
{detailed analysis with code diff examples}

### Code Refactoring
{detailed analysis with refactoring examples found}

### Developer Testing
{detailed analysis with test coverage observations}

### Code Review
{detailed analysis with review participation data}

## Improvement Suggestions

1. {suggestion 1}
2. {suggestion 2}
3. {suggestion 3}

## Highlights

- {positive observation 1}
- {positive observation 2}
```

## Error Handling

- If API returns 401: Token is invalid or expired. Ask user to regenerate at https://gitcode.com/setting/token-classic.
- If API returns 404: Repository or user not found. Verify the repo path and username.
- If API returns 429: Rate limited. Retry with exponential backoff (2s, 4s, 8s), up to 3 retries.
- If no commits found: Display a clear message with troubleshooting steps (verify username, date range, repos).
- If token is missing (neither parameter nor env var): Stop immediately and show instructions for both methods.

## Notes

- GitCode API rate limit: 400 requests/minute, 4000 requests/hour
- For large repositories, paginate all API calls (per_page=100)
- Sample up to 10 commits for AI diff analysis to stay within reasonable time
- All dates should be in ISO 8601 format
- The `author` parameter in commits API accepts username or email
- Token passed as argument takes priority over `$env:GITCODE_TOKEN`
